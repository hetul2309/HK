import java.util.Scanner;

public class power_calculation {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter base : ");
        int b = sc.nextInt();
        System.out.print("Enter power : ");
        int p = sc.nextInt();
        int i = 1;
        while(p!=0)
        {
            i = b*i;
            p--;
        }
        System.out.print("Answer = "+i); 
    }
}
