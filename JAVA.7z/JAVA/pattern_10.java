import java.util.Scanner;

public class pattern_10 {
    /*
    //Butterfly Pattern
     *  *             *
     *  * *         * *
     *  * * *     * * *
     *  * * * * * * * *
     *  * * * * * * * *
     *  * * *     * * *
     *  * *         * *
     *  *             *
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter input : ");
        int n = sc.nextInt();
        for(int i=1; i<=2*n;i++)
        {
            if(i<=n)
            {
                for(int j=1;j<=i;j++)
                {
                    System.out.print("* ");
                }
                for(int j=n-1;j>=i;j--)
                {
                    System.out.print("  ");
                }
                for(int j=n-1;j>=i;j--)
                {
                    System.out.print("  ");
                }
                for(int k=1;k<=i;k++)
                {
                    System.out.print("* ");
                }
            }
            else
            {
                for(int j=2*n;j>=i;j--)
                {
                    System.out.print("* ");
                }
                for(int j=n+1;j<i;j++)
                {
                    System.out.print("  ");
                }
                for(int j=n+1;j<i;j++)
                {
                    System.out.print("  ");
                }
                for(int j=2*n;j>=i;j--)
                {
                    System.out.print("* ");
                }
                
            }
            System.out.println();
        }
    }
}
