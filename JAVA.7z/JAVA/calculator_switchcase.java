import java.util.Scanner;

public class calculator_switchcase {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter Two Numbers :");
        double a = scan.nextDouble();
        double b = scan.nextDouble();
        System.out.println("Operators are :\n+ for Addition\n- for Subtraction");
        System.out.println("x for Multiplication\n/ for Division");
        System.out.print("Enter the operator : ");
        char c = scan.next().charAt(0);
        switch (c) {
            case '+':
                System.out.println("Sum = " + (a + b));
                break;
            case '-':
                System.out.println("Differenve = " + (a - b));
                break;
            case 'x':
                System.out.println("Product = " + (a * b));
                break;
            case '/':
                System.out.println("Division = " + (a / b));
                break;
            default:
                System.out.println("Invalid Operator");
        }

    }
}
